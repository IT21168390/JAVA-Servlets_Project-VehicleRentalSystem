//IT21169212 M.A.T.M.Wanshathilaka ADBConnection.java
package adminDB;

import java.sql.Connection;
import java.sql.DriverManager;

public class ADBConnection {
	
	//DB connection
	private static String url = "jdbc:mysql://localhost:3306/vehiclerentalsystem"; //jdbc:mysql://localhost:3306/table name 
	private static String user = "root";
	private static String pass = "Hashan2000"; //Plz remember me to change password
	private static Connection con;
	
	public static Connection getConnection() {
		
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			
			con = DriverManager.getConnection(url, user, pass);
			
		}
		catch (Exception e) {
			
			System.out.println("Database Connection Error!");
		}
		
		return con;
	}
	
}
