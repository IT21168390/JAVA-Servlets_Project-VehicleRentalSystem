// IT21169212 M.A.T.M.Wanshathilaka AdminDBUtil.java
package adminDB;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import adminModel.AdminDetails;

public class AdminDBUtil {
	
	private static boolean isSuccess;
	private static Connection con = null;
	private static Statement stmt = null;
	private static ResultSet rs = null;
	
	//AdminLogin
	public static boolean validate(String AUID,String APassword) {
		
		try {
			
			con = ADBConnection.getConnection();
			stmt = con.createStatement();
			
			String sql = "select * from admin_db where AUID = '"+AUID+"' and APassword ='"+APassword+"'";
			rs = stmt.executeQuery(sql);
			
			if (rs.next()){
				isSuccess = true;
			}
			else {
				isSuccess = false;
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return isSuccess;
	}

	//ViewAdminDetails Section
	public static List<AdminDetails> validate(String AUID){
		
	ArrayList <AdminDetails> Adet = new ArrayList<>();
	
	//Validation
	try {
		con = ADBConnection.getConnection();
		stmt = con.createStatement();
		
		String sql = "select * from admin_db where AUID = '"+AUID+"' ";
		rs = stmt.executeQuery(sql);
		
		if (rs.next()) {
			String auid = rs.getString(1);
			String aname = rs.getString(2);
			String aemail = rs.getString(3);
			String atel = rs.getString(4);
			String apass = rs.getString(5);
			
			AdminDetails ad = new AdminDetails(auid,aname,aemail,atel,apass);
			Adet.add(ad);
		} 
	}
	catch(Exception e) {
		e.printStackTrace();
	}
	
	return Adet;
	}
	
	//Adding Section
	public static boolean insertAdmin(String AUID, String AName,String AEmail, String ATelephoneNo, String APassword) {
		
		boolean isSuccess = false;
		
		try {
			
			con = ADBConnection.getConnection();
			stmt = con.createStatement();
			String sql = "insert into admin_db values ('"+AUID+"', '"+AName+"', '"+AEmail+"', '"+ATelephoneNo+"', '"+APassword+"')";
			int Ars = stmt.executeUpdate(sql);
			
			if (Ars > 0) {
				isSuccess = true;
			} else {
				isSuccess = false;
			}
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return isSuccess ;
		
	}
	
	//Update Section
	public static boolean UpdateAdmin(String AUID, String AName, String AEmail, String ATelephoneNo, String APassword) {
		
		boolean isSuccess = false;
		
		try {
			
			con = ADBConnection.getConnection();
			stmt = con.createStatement();
			String sql = "update admin_db set AName = '"+AName+"', AEmail = '"+AEmail+"', ATelephoneNo = '"+ATelephoneNo+"', APassword = '"+APassword+"'"
					+ "where AUID = '"+AUID+"'";
			int Ars = stmt.executeUpdate(sql);
			
			if (Ars > 0) {
				isSuccess = true;
			}
			else {
				isSuccess = false;
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return isSuccess ;
	}
	
	//Retrieve Admin Details
	public static List<AdminDetails> getAdminDetails(String AUID){
		
		ArrayList<AdminDetails> Adet = new ArrayList<>();
		
		try {
			
			con = ADBConnection.getConnection();
			stmt = con.createStatement();
			String sql = "select * from admin_db where AUID = '"+AUID+"'";
			rs = stmt.executeQuery(sql);
			
			while(rs.next()) {
				
				String auid = rs.getString(1);
				String aname = rs.getString(2);
				String aemail = rs.getString(3);
				String atel = rs.getString(4);
				String apass = rs.getString(5);
				
				AdminDetails Ad = new AdminDetails(auid,aname,aemail,atel,apass);
				Adet.add(Ad);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return Adet;
		
	}
	
	//Delete Admin Detail
	public static boolean DeleteAdmin(String AUID) {
		
		try {
			
			con = ADBConnection.getConnection();
			stmt = con.createStatement();
			String sql = "DELETE FROM admin_db WHERE AUID = '"+AUID+"'";
			int rsd = stmt.executeUpdate(sql);
			
			if (rsd > 0) {
				isSuccess = true;
			}
			else {
				isSuccess = false;
			}
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return isSuccess;
	}
}
