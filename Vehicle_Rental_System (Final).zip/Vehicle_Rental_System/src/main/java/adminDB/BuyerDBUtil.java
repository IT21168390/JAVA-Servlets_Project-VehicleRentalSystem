// IT21169212 M.A.T.M.Wanshathilaka BuyerDBUtil.java
package adminDB;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import adminModel.BuyerDetails;

public class BuyerDBUtil {
	
	private static boolean isSuccess;
	private static Connection con = null;
	private static Statement stmt = null;
	private static ResultSet rs = null;

	//ViewBuyerDetails Section
	public static List<BuyerDetails> validate(String BUID){
		
	ArrayList <BuyerDetails> Bdet = new ArrayList<>();
	
	//Validation
	try {
		con = BDBConnection.getConnection();
		stmt = con.createStatement();
		
		String sql = "select * from buyer_db where BUID = '"+BUID+"' ";
		rs = stmt.executeQuery(sql);
		
		if (rs.next()) {
			String buid = rs.getString(1);
			String bname = rs.getString(2);
			String bemail = rs.getString(3);
			String btel = rs.getString(4);
			String bpass = rs.getString(5);
			
			BuyerDetails bd = new BuyerDetails(buid,bname,bemail,btel,bpass);
			Bdet.add(bd);
		} 
	}
	catch(Exception e) {
		e.printStackTrace();
	}
	
	return Bdet;
	}
	
	//Adding Section
	public static boolean insertBuyer(String BUID, String BName,String BEmail, String BTelephoneNo, String BPassword) {
		
		boolean isSuccess = false;
		
		try {
			
			con = BDBConnection.getConnection();
			stmt = con.createStatement();
			String sql = "insert into buyer_db values ('"+BUID+"', '"+BName+"', '"+BEmail+"', '"+BTelephoneNo+"', '"+BPassword+"')";
			int Brs = stmt.executeUpdate(sql);
			
			if (Brs > 0) {
				isSuccess = true;
			} else {
				isSuccess = false;
			}
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return isSuccess ;
		
	}
	
	//Update Section
	public static boolean UpdateBuyer(String BUID, String BName, String BEmail, String BTelephoneNo, String BPassword) {
		
		boolean isSuccess = false;
		
		try {
			
			con = BDBConnection.getConnection();
			stmt = con.createStatement();
			String sql = "update buyer_db set BName = '"+BName+"', BEmail = '"+BEmail+"', BTelephoneNo = '"+BTelephoneNo+"', BPassword = '"+BPassword+"'"
					+ "where BUID = '"+BUID+"'";
			int Brs = stmt.executeUpdate(sql);
			
			if (Brs > 0) {
				isSuccess = true;
			}
			else {
				isSuccess = false;
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return isSuccess ;
	}
	
	//Retrieve Buyer Details
	public static List<BuyerDetails> getBuyerDetails(String BUID){
		
		ArrayList<BuyerDetails> Bdet = new ArrayList<>();
		
		try {
			
			con = BDBConnection.getConnection();
			stmt = con.createStatement();
			String sql = "select * from buyer_db where BUID = '"+BUID+"'";
			rs = stmt.executeQuery(sql);
			
			while(rs.next()) {
				
				String buid = rs.getString(1);
				String bname = rs.getString(2);
				String bemail = rs.getString(3);
				String btel = rs.getString(4);
				String bpass = rs.getString(5);
				
				BuyerDetails Bd = new BuyerDetails(buid,bname,bemail,btel,bpass);
				Bdet.add(Bd);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return Bdet;
		
	}
	
	//Delete Buyer Detail
	public static boolean DeleteBuyer(String BUID) {
		
		try {
			
			con = BDBConnection.getConnection();
			stmt = con.createStatement();
			String sql = "DELETE FROM buyer_db WHERE BUID = '"+BUID+"'";
			int rsd = stmt.executeUpdate(sql);
			
			if (rsd > 0) {
				isSuccess = true;
			}
			else {
				isSuccess = false;
			}
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return isSuccess;
	}
}
