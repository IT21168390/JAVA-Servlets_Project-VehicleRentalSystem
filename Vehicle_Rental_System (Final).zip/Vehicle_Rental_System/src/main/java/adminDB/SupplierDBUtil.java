// IT21169212 M.A.T.M.Wanshathilaka SupplierDBUtil.java
package adminDB;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import adminModel.SupplierDetails;

public class SupplierDBUtil {
	
	private static boolean isSuccess;
	private static Connection con = null;
	private static Statement stmt = null;
	private static ResultSet rs = null;
	
	
	//ViewSupplierDetails Section
	public static List<SupplierDetails> validate(String SUID){
		
	ArrayList <SupplierDetails> Sdet = new ArrayList<>();
	
	//Validation
	try {
		con = SDBConnection.getConnection();
		stmt = con.createStatement();
		
		String sql = "select * from supplier_db where SUID = '"+SUID+"' ";
		rs = stmt.executeQuery(sql);
		
		if (rs.next()) {
			String suid = rs.getString(1);
			String sname = rs.getString(2);
			String semail = rs.getString(3);
			String stel = rs.getString(4);
			String spass = rs.getString(5);
			
			SupplierDetails ad = new SupplierDetails(suid,sname,semail,stel,spass);
			Sdet.add(ad);
		} 
	}
	catch(Exception e) {
		e.printStackTrace();
	}
	
	return Sdet;
	}
	
	//Adding Section
	public static boolean insertSupplier(String SUID, String SName,String SEmail, String STelephoneNo, String SPassword) {
		
		boolean isSuccess = false;
		
		try {
			
			con = SDBConnection.getConnection();
			stmt = con.createStatement();
			String sql = "insert into supplier_db values ('"+SUID+"', '"+SName+"', '"+SEmail+"', '"+STelephoneNo+"', '"+SPassword+"')";
			int Srs = stmt.executeUpdate(sql);
			
			if (Srs > 0) {
				isSuccess = true;
			} else {
				isSuccess = false;
			}
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return isSuccess ;
		
	}
	
	//Update Section
	public static boolean UpdateSupplier(String SUID, String SName, String SEmail, String STelephoneNo, String SPassword) {
		
		boolean isSuccess = false;
		
		try {
			
			con = SDBConnection.getConnection();
			stmt = con.createStatement();
			String sql = "UPDATE supplier_db SET SName = '"+SName+"', SEmail = '"+SEmail+"', STelephoneNo = '"+STelephoneNo+"', SPassword = '"+SPassword+"'"
					+ "WHERE SUID = '"+SUID+"'";
			int Srs = stmt.executeUpdate(sql);
			
			if (Srs > 0) {
				isSuccess = true;
			}
			else {
				isSuccess = false;
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return isSuccess ;
	}
	
	//Retrieve Supplier Details
	public static List<SupplierDetails> getSupplierDetails(String SUID){
		
		ArrayList<SupplierDetails> Sdet = new ArrayList<>();
		
		try {
			
			con = SDBConnection.getConnection();
			stmt = con.createStatement();
			String sql = "select * from supplier_db where SUID = '"+SUID+"'";
			rs = stmt.executeQuery(sql);
			
			while(rs.next()) {
				
				String suid = rs.getString(1);
				String sname = rs.getString(2);
				String semail = rs.getString(3);
				String stel = rs.getString(4);
				String spass = rs.getString(5);
				
				SupplierDetails Sd = new SupplierDetails(suid,sname,semail,stel,spass);
				Sdet.add(Sd);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return Sdet;
		
	}
	
	//Delete Supplier Detail
	public static boolean DeleteSupplier(String SUID) {
		
		try {
			
			con = SDBConnection.getConnection();
			stmt = con.createStatement();
			String sql = "DELETE FROM supplier_db WHERE SUID = '"+SUID+"'";
			int rsd = stmt.executeUpdate(sql);
			
			if (rsd > 0) {
				isSuccess = true;
			}
			else {
				isSuccess = false;
			}
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return isSuccess;
	}
}

