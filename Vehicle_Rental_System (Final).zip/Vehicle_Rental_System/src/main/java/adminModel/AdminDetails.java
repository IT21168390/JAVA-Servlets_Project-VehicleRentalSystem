// IT21169212 M.A.T.M.Wanshathilaka AdminDetails.java
package adminModel;

public class AdminDetails {
	
	private String AUID;
	private String AName;
	private String AEmail;
	private String ATelephoneNo;
	private String APassword;
	
	public AdminDetails(String aUID, String aName, String aEmail, String aTelephoneNo, String aPassword) {

		this.AUID = aUID;
		this.AName = aName;
		this.AEmail = aEmail;
		this.ATelephoneNo = aTelephoneNo;
		this.APassword = aPassword;
	}

	public String getAUID() {
		return AUID;
	}

	public String getAName() {
		return AName;
	}

	public String getAEmail() {
		return AEmail;
	}

	public String getATelephoneNo() {
		return ATelephoneNo;
	}

	public String getAPassword() {
		return APassword;
	}
	
}
