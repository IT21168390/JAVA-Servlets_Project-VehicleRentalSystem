// IT21169212 M.A.T.M.Wanshathilaka BuyerDetails.java
package adminModel;

public class BuyerDetails {
	
	private String BUID;
	private String BName;
	private String BEmail;
	private String BTelephoneNo;
	private String BPassword;
	
	public BuyerDetails(String bUID, String bName, String bEmail, String bTelephoneNo, String bPassword) {

		this.BUID = bUID;
		this.BName = bName;
		this.BEmail = bEmail;
		this.BTelephoneNo = bTelephoneNo;
		this.BPassword = bPassword;
	}

	public String getBUID() {
		return BUID;
	}

	public String getBName() {
		return BName;
	}

	public String getBEmail() {
		return BEmail;
	}

	public String getBTelephoneNo() {
		return BTelephoneNo;
	}

	public String getBPassword() {
		return BPassword;
	}
	
}
