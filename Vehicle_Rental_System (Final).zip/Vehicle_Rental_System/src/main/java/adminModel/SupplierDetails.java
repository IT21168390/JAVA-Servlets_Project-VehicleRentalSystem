// IT21169212 M.A.T.M.Wanshathilaka AdminDetails.java
package adminModel;

public class SupplierDetails {
	
	private String SUID;
	private String SName;
	private String SEmail;
	private String STelephoneNo;
	private String SPassword;
	
	public SupplierDetails(String sUID, String sName, String sEmail, String sTelephoneNo, String sPassword) {

		this.SUID = sUID;
		this.SName = sName;
		this.SEmail = sEmail;
		this.STelephoneNo = sTelephoneNo;
		this.SPassword = sPassword;
	}

	public String getSUID() {
		return SUID;
	}

	public String getSName() {
		return SName;
	}

	public String getSEmail() {
		return SEmail;
	}

	public String getSTelephoneNo() {
		return STelephoneNo;
	}

	public String getSPassword() {
		return SPassword;
	}
	
}
