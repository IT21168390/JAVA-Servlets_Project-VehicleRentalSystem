// IT21169212 M.A.T.M.Wanshathilaka AdminInsertServlet.java
package adminServlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import adminDB.AdminDBUtil;

@WebServlet("/AdminInsertServlet")
public class AdminInsertServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String AUID =  request.getParameter("AUID");
		String AName =  request.getParameter("AName");
		String AEmail =  request.getParameter("AEmail");
		String ATelephoneNo =  request.getParameter("ATelephoneNo");
		String APassword =  request.getParameter("APassword");
		
		boolean isTrue;
		
		isTrue = AdminDBUtil.insertAdmin(AUID, AName, AEmail, ATelephoneNo, APassword);
		
		if (isTrue == true) {
			RequestDispatcher dis = request.getRequestDispatcher("AdminSuccess.jsp");
			dis.forward(request, response);

		}
		else {
			RequestDispatcher dis2 = request.getRequestDispatcher("AdminUnsuccess.jsp");
			dis2.forward(request,response);
		}
	}

}
