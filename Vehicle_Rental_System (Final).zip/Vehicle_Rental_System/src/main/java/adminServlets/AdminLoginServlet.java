//IT21169212 M.A.T.M.Wanshathilaka AdminLoginServlet.jsp
package adminServlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import adminDB.AdminDBUtil;

@WebServlet("/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		
		String AUserID = request.getParameter("AUID");
		String APass = request.getParameter("APassword");
		boolean isTrue;
		
		isTrue = AdminDBUtil.validate(AUserID, APass);
		
		if (isTrue == true) {
			RequestDispatcher dis = request.getRequestDispatcher("AdminToolPage.jsp");
			dis.forward(request, response);
		}
		else {
			out.println("<script type ='text/javascript'>");
			out.println("alert('UserID & Password are incorrect!');");
			out.println("location = 'AdminLogin.jsp'");
			out.println("</script>");
		}
	}

}
