// IT21169212 M.A.T.M.Wanshathilaka BuyerInsertServlet.java
package adminServlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import adminDB.BuyerDBUtil;

@WebServlet("/BuyerInsertServlet")
public class BuyerInsertServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String BUID =  request.getParameter("BUID");
		String BName =  request.getParameter("BName");
		String BEmail =  request.getParameter("BEmail");
		String BTelephoneNo =  request.getParameter("BTelephoneNo");
		String BPassword =  request.getParameter("BPassword");
		
		boolean isTrue;
		
		isTrue = BuyerDBUtil.insertBuyer(BUID, BName, BEmail, BTelephoneNo, BPassword);
		
		if (isTrue == true) {
			RequestDispatcher dis = request.getRequestDispatcher("AdminSuccess.jsp");
			dis.forward(request, response);

		}
		else {
			RequestDispatcher dis2 = request.getRequestDispatcher("AdminUnsuccess.jsp");
			dis2.forward(request,response);
		}
		
	}

}
