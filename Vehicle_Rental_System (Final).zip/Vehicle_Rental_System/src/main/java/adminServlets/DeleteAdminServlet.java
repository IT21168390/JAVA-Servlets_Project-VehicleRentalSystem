//IT21169212 M.A.T.M.Wanshathilaka DeleteAdminServlet.jsp

package adminServlets;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import adminDB.AdminDBUtil;

@WebServlet("/DeleteAdminServlet")
public class DeleteAdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String AUID = request.getParameter("AUID");
		boolean isTrue;
		
		isTrue = AdminDBUtil.DeleteAdmin(AUID);
		
		if (isTrue == true) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("AddAdmin.jsp");
			dispatcher.forward(request, response); 
		}
		else {
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("AdminViewAdminDetails.jsp");
			dispatcher.forward(request, response);
		}
	}

}
