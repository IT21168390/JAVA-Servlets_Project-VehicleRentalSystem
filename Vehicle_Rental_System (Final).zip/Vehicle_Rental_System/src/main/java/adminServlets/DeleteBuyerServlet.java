//IT21169212 M.A.T.M.Wanshathilaka DeleteBuyerServlet.jsp
package adminServlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import adminDB.BuyerDBUtil;

@WebServlet("/DeleteBuyerServlet")
public class DeleteBuyerServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String BUID = request.getParameter("BUID");
		boolean isTrue;
		
		isTrue = BuyerDBUtil.DeleteBuyer(BUID);
		
		if (isTrue == true) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("AddBuyer.jsp");
			dispatcher.forward(request, response); 
		}
		else {
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("AdminViewBuyerDetails.jsp");
			dispatcher.forward(request, response);
		}
		
	}

}
