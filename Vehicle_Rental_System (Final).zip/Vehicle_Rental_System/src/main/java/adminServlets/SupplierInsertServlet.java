// IT21169212 M.A.T.M.Wanshathilaka SupplierInsertServlet.java
package adminServlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import adminDB.SupplierDBUtil;

@WebServlet("/SupplierInsertServlet")
public class SupplierInsertServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String SUID =  request.getParameter("SUID");
		String SName =  request.getParameter("SName");
		String SEmail =  request.getParameter("SEmail");
		String STelephoneNo =  request.getParameter("STelephoneNo");
		String SPassword =  request.getParameter("SPassword");
		
		boolean isTrue;
		
		isTrue = SupplierDBUtil.insertSupplier(SUID, SName, SEmail, STelephoneNo, SPassword);
		
		if (isTrue == true) {
			RequestDispatcher dis = request.getRequestDispatcher("AdminSuccess.jsp");
			dis.forward(request, response);

		}
		else {
			RequestDispatcher dis2 = request.getRequestDispatcher("AdminUnsuccess.jsp");
			dis2.forward(request,response);
		}
		
	}

}
