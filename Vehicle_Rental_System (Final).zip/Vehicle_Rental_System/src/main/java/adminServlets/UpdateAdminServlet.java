//IT21169212 M.A.T.M.Wanshathilaka UpdaetAdminServlet.java
package adminServlets;

import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import adminDB.AdminDBUtil;
import adminModel.AdminDetails;

@WebServlet("/UpdateAdminServlet")
public class UpdateAdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String AUID = request.getParameter("AUID");
		String AName = request.getParameter("AName");
		String AEmail = request.getParameter("AEmail");
		String ATelephoneNo = request.getParameter("ATelephoneNo");
		String APassword = request.getParameter("APassword");
		
		boolean isTrue;
		
		isTrue = AdminDBUtil.UpdateAdmin(AUID, AName, AEmail, ATelephoneNo, APassword);
		
		if(isTrue == true) {
			
			List<AdminDetails> ViewAdetail = AdminDBUtil.getAdminDetails(AUID);
			request.setAttribute("ViewAdetail", ViewAdetail);
			
			RequestDispatcher dis = request.getRequestDispatcher("AdminAccount.jsp");
			dis.forward(request, response);
		}
		else {
			RequestDispatcher dis = request.getRequestDispatcher("AdminUnsuccess.jsp");
			dis.forward(request, response);
		}
	}

}
