//IT21169212 M.A.T.M.Wanshathilaka UpdaetBuyerServlet.java
package adminServlets;

import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import adminDB.BuyerDBUtil;
import adminModel.BuyerDetails;

@WebServlet("/UpdateBuyerServlet")
public class UpdateBuyerServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String BUID = request.getParameter("BUID");
		String BName = request.getParameter("BName");
		String BEmail = request.getParameter("BEmail");
		String BTelephoneNo = request.getParameter("BTelephoneNo");
		String BPassword = request.getParameter("BPassword");
		
		boolean isTrue;
		
		isTrue = BuyerDBUtil.UpdateBuyer(BUID, BName, BEmail, BTelephoneNo, BPassword);
		
		if(isTrue == true) {
			
			List<BuyerDetails> ViewBdetail = BuyerDBUtil.getBuyerDetails(BUID);
			request.setAttribute("ViewBdetail", ViewBdetail);
			
			RequestDispatcher dis = request.getRequestDispatcher("AdminBuyerAccount.jsp");
			dis.forward(request, response);
		}
		else {
			RequestDispatcher dis = request.getRequestDispatcher("AdminUnsuccess.jsp");
			dis.forward(request, response);
		}
		
	}

}
