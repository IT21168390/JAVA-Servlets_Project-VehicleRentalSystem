//IT21169212 M.A.T.M.Wanshathilaka UpdaetSupplierServlet.java
package adminServlets;

import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import adminDB.SupplierDBUtil;
import adminModel.SupplierDetails;

@WebServlet("/UpdateSupplierServlet")
public class UpdateSupplierServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String SUID = request.getParameter("SUID");
		String SName = request.getParameter("SName");
		String SEmail = request.getParameter("SEmail");
		String STelephoneNo = request.getParameter("STelephoneNo");
		String SPassword = request.getParameter("SPassword");
		
		boolean isTrue;
		
		isTrue = SupplierDBUtil.UpdateSupplier(SUID, SName, SEmail, STelephoneNo, SPassword);
		
		if(isTrue == true) {
			
			List<SupplierDetails> ViewSdetail = SupplierDBUtil.getSupplierDetails(SUID);
			request.setAttribute("ViewSdetail", ViewSdetail);
			
			RequestDispatcher dis = request.getRequestDispatcher("AdminSupplierAccount.jsp");
			dis.forward(request, response);
		}
		else {
			RequestDispatcher dis = request.getRequestDispatcher("AdminUnsuccess.jsp");
			dis.forward(request, response);
		}
		
	}

}
