// IT21169212 M.A.T.M.Wanshathilaka ViewBuyerDetailsServlet.java
package adminServlets;

import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import adminDB.BuyerDBUtil;
import adminModel.BuyerDetails;

@WebServlet("/ViewBuyerDetailsServlet")
public class ViewBuyerDetailsServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String BUserID = request.getParameter("BUID");
		
		try {
		List<BuyerDetails> ViewBdetail = BuyerDBUtil.validate(BUserID);
		request.setAttribute("ViewBdetail", ViewBdetail);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		RequestDispatcher dis = request.getRequestDispatcher("AdminBuyerAccount.jsp");
		dis.forward(request, response);
		
	}

}
