// IT21169212 M.A.T.M.Wanshathilaka ViewSupplierDetailsServlet.java
package adminServlets;

import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import adminDB.SupplierDBUtil;
import adminModel.SupplierDetails;

@WebServlet("/ViewSupplierDetailsServlet")
public class ViewSupplierDetailsServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String SUserID = request.getParameter("SUID");
		
		try {
		List<SupplierDetails> ViewSdetail = SupplierDBUtil.validate(SUserID);
		request.setAttribute("ViewSdetail", ViewSdetail);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		RequestDispatcher dis = request.getRequestDispatcher("AdminSupplierAccount.jsp");
		dis.forward(request, response);
		
	}

}
