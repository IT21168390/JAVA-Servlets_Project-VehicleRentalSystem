package supplierDB;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import supplierModel.user;

public class userdbutil {
	private static boolean isSuccess;
	private static Connection con = null;
	private static Statement stmt = null;
	private static ResultSet rs = null;
    
	public static boolean validate(String username, String password) {
		
		try {
			con = databaseconector.getConnection();
			stmt = con.createStatement();
			
			/* sql query for validation*/
			String sql = "select * from supplier where name='"+username+"' and password='"+password+"'";
			rs = stmt.executeQuery(sql);
			
			if (rs.next()) {
				isSuccess = true;
			} else {
				isSuccess = false;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return isSuccess;
	}
	
	public static List<user> getuser(String username) {
		
		ArrayList<user> user = new ArrayList<>();
		
		try {
			
			con = databaseconector.getConnection();
			stmt = con.createStatement();
			String sql = "select * from supplier where name='"+username+"'";
			rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				int id = rs.getInt(1);
				String name = rs.getString(2);
				String address = rs.getString(3);
				String gender = rs.getString(4);
				String email = rs.getString(5);
				String phone = rs.getString(6);
				String password = rs.getString(7);
				
			user cus = new user(id,name,address,gender,email,phone,password);
				user.add(cus);
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return user;	
	}
	
    /* to catch details from insert jsp*/
    public static boolean userinsert(String name, String address, String gender, String email, String phone, String password) {
    	boolean isSuccess = false;
    	
    	try {
    		con = databaseconector.getConnection();
    		stmt = con.createStatement();
    		/* sql for insert data */
    	    String sql = "insert into supplier values (0,'"+name+"', '"+address+"', '"+gender+"','"+email+"','"+phone+"','"+password+"')";
    		int rs = stmt.executeUpdate(sql);
    		
    		if(rs > 0) {
    			isSuccess = true;
    		} else {
    			isSuccess = false;
    		}	
    	}
    	catch (Exception e) {
    		e.printStackTrace();
    	}
 	
    	return isSuccess;
    }
    
    /*for uptate data*/
    public static boolean updateuser(String id, String name, String address, String gender, String email, String phone,  String password) {
    	
    	try {
    		
    		con = databaseconector.getConnection();
    		stmt = con.createStatement();
    		/*sql query for update data */
    		String sql = "update supplier set name='"+name+"',address='"+address+"',gender='"+gender+"',email='"+email+"',phone='"+phone+"',password='"+password+"'"
    				+ "where id='"+id+"'";
    		int rs = stmt.executeUpdate(sql);
    		
    		if(rs > 0) {
    			isSuccess = true;
    		}
    		else {
    			isSuccess = false;
    		}
    		
    	}
    	catch(Exception e) {
    		e.printStackTrace();
    	}
    	
    	return isSuccess;
    }
    
 /*.......retreving data from database...............*/
    public static List<user> getuserDetail(String Id) {
    	
    	int convertedID = Integer.parseInt(Id);
    	/*reterun data from arry list...*/
    	ArrayList<user> cus = new ArrayList<>();
    	
    	try {
    		/*create database connection for retrieve data*/
    		con = databaseconector.getConnection();
    		stmt = con.createStatement();
    		/*sql query for retrieve data*/
    		String sql = "select * from supplier where id='"+convertedID+"'";
    		rs = stmt.executeQuery(sql);
    		
    		/*assign data base using while loop ......*/
    		while(rs.next()) {
    			int id = rs.getInt(1);
    			String name = rs.getString(2);
    			String address = rs.getString(3);
    			String gender = rs.getString(4);
    			String email = rs.getString(5);
    			String phone = rs.getString(6);
    			String password = rs.getString(7);
    			
    			/*passing above variable to object.....*/
    			user u = new user(id,name,address,gender,email,phone,password);
    			cus.add(u);
    		}
    		
    	}
    	catch(Exception e) {
    		e.printStackTrace();
    	}	
    	return cus;	
    }
    
    /*deleting data from database......*/
    public static boolean deleteuser(String id) {
    	
    	/*convert string variable to integer.......*/
    	int convId = Integer.parseInt(id);
    	
    	try {
    		/* data base connection for deletion....*/
    		con = databaseconector.getConnection();
    		stmt = con.createStatement();
    		/*sql query for deletion...*/
    		String sql = "delete from supplier where id='"+convId+"'";
    		int r = stmt.executeUpdate(sql);
    		
    		if (r > 0) {
    			isSuccess = true;
    		}
    		else {
    			isSuccess = false;
    		}
    		
    	}
    	catch (Exception e) {
    		e.printStackTrace();
    	}
    	
    	return isSuccess;
    }
}
