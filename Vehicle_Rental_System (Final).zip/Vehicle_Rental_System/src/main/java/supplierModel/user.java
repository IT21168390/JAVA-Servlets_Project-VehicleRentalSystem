package supplierModel;

public class user {
	 private int id;
	    private String name;
	    private String address;
	    private String gender;
	    private String email;
	    private String phone;
	    private String password;
	    
	    /* overloaded costructor to set values*/
	    public user(int id, String name, String address, String gender, String email, String phone, String password) {
		this.id = id;
		this.name = name;
		this.address = address;
		this.gender = gender;
		this.email = email;
		this.phone = phone;
		this.password = password;
	    }
	    
	    /*setters and getters*/
	    public int getId() {
	        return id;
	    }

	    public String getName() {
	        return name;
	    }
	    
	    public String getAddress() {
	        return address;
	    }
	    
	    public String getGender() {
	        return gender;
	    }
	    
	    public String getEmail() {
	        return email;
	    }

	    public String getPhone() {
	        return phone;
	    }

	    public String getPassword() {
	        return password;
	    }    

}
