package supplierServlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import supplierDB.userdbutil;
import supplierModel.user;


@WebServlet("/Deleteuserservlet")
public class Deleteuserservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		/* catch data from delete*/  
		String id = request.getParameter("uid");
		boolean isTrue;
		
		isTrue = userdbutil.deleteuser(id);
		
		/*nevigate for pages*/
		if (isTrue == true) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("SupplierSuccess.jsp");
			dispatcher.forward(request, response);
		}
		else {
			
			List<user> userDetail = userdbutil.getuserDetail(id);
			request.setAttribute("userDetail", userDetail);
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("SupplierUnsuccess.jsp");
			dispatcher.forward(request, response);
		}
		
		
		
	}

}
