package supplierServlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import supplierDB.userdbutil;

@WebServlet("/Insertuserservlet")
public class Insertuserservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/*to catch data insert.jsp page*/
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		String address = request.getParameter("address");
		String gender = request.getParameter("gender");
		String email = request.getParameter("email");
		String phone = request.getParameter("phone");
		String password = request.getParameter("psw");
		
		boolean isTrue;
		
		isTrue = userdbutil.userinsert(name, address, gender, email, phone, password);
		/* pass new insert data*/
		if(isTrue == true) {
			RequestDispatcher dis = request.getRequestDispatcher("SupplierSuccess.jsp");
			dis.forward(request, response);
		} else {
			RequestDispatcher dis2 = request.getRequestDispatcher("SupplierUnsuccess.jsp");
			dis2.forward(request, response);
		}
	}

}
