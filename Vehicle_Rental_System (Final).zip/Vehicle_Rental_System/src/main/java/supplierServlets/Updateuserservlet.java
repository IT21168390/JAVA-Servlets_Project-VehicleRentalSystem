package supplierServlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import supplierDB.userdbutil;
import supplierModel.user;


@WebServlet("/UpdateuserServlet")
public class Updateuserservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/*to pass data from update*/
		String id = request.getParameter("uid");
		String name = request.getParameter("name");
		String address = request.getParameter("address");
		String gender = request.getParameter("gender");
		String email = request.getParameter("email");
		String phone = request.getParameter("phone");
		String password = request.getParameter("pass");
		
		boolean isTrue;
		/*get data from update page*/
		isTrue = userdbutil.updateuser(id, name, address, gender, email, phone, password);
		if(isTrue == true) {
			
			List<user> userDetail = userdbutil.getuserDetail(id);
			request.setAttribute("userDetail", userDetail);
			/*navigate to next page*/
			RequestDispatcher dis = request.getRequestDispatcher("SupplierSuccess.jsp");
			dis.forward(request, response);
		}
		else {
			
			List<user> userDetail = userdbutil.getuserDetail(id);
			request.setAttribute("userDetail", userDetail);
			/*navigate to next page*/
			RequestDispatcher dis = request.getRequestDispatcher("SupplierUnsuccess.jsp");
			dis.forward(request, response);
		}
	}

}

