package userServlets;

import java.io.IOException;
import java.io.PrintWriter;

//import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import userDB.CustomerDBUtil;

@WebServlet("/ContactServlet")
public class ContactServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		
		//Get the Contact form data to pass through the Message Sending method...
		String fName = request.getParameter("FirstName");
		String lName = request.getParameter("LastName");
		String email = request.getParameter("email");
		String message = request.getParameter("Message");
		
		boolean isTrue;
		
		isTrue = CustomerDBUtil.sentMessage(fName, lName, email, message);

		//Show a status alert and redirect the user to the Contact page again.
		if (isTrue == true) {
			out.println("<script type='text/javascript'>");
			out.println("alert('Message Sent!');");
			out.println("location='Contact.jsp'");
			out.println("</script>");
		} else {
			out.println("<script type='text/javascript'>");
			out.println("alert('Error! Message sending failed!');");
			out.println("location='Contact.jsp'");
			out.println("</script>");
		}
		
	}

}
